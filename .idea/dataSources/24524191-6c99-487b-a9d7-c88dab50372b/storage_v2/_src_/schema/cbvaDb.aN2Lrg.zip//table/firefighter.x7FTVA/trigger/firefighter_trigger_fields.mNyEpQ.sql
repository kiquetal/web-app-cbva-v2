create trigger firefighter_trigger_fields
  before UPDATE
  on firefighter
  for each row
  BEGIN
          SET @fecha=curdate();
          SET NEW.update_date=@fecha;
  end;

