create trigger chk_present_instructor_attendance
  after INSERT
  on instructor_activity
  for each row
  BEGIN
            INSERT into attendance_activity(person_id, activity_id,start_activity,end_activity,is_instructor) VALUES (new.instructor_id,NEW.activity_id,New.start_activity,NEW.end_activity,true );

    end;

