create trigger chk_before_insert_instructor
  before INSERT
  on instructor_activity
  for each row
  BEGIN

      DECLARE start_date_activity DATETIME;
      DECLARE end_date_activity DATETIME;

      SELECT start_date from activity WHERE activity.id=NEW.activity_id INTO start_date_activity;
      SELECT end_date from activity WHERE activity.id=NEW.activity_id INTO end_date_activity;

      IF (NEW.start_activity < start_date_activity OR NEW.end_activity >end_date_activity) THEN

        SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Your input date are invalids,check TABLE ACTIVITY ';

      end if ;

    end;

