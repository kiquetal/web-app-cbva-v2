create trigger update_present_instructor_attendance
  after UPDATE
  on instructor_activity
  for each row
  BEGIN
      UPDATE attendance_activity
        SET start_activity=NEW.start_activity,end_activity=NEW.end_activity
      WHERE person_id=NEW.instructor_id AND attendance_activity.activity_id=NEW.activity_id;
    end;

