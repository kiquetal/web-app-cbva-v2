create trigger chk_present_attendance
  before INSERT
  on attendance_activity
  for each row
  BEGIN


     DECLARE minutes INT;
     DECLARE thresold INT;
     DECLARE start_date_activity DATETIME;
     DECLARE end_date_activity DATETIME;

     SELECT threshold from activity WHERE activity.id=NEW.activity_id INTO thresold;
     SELECT start_date from activity WHERE activity.id=NEW.activity_id INTO start_date_activity;
     SELECT end_date from activity WHERE activity.id=NEW.activity_id INTO end_date_activity;

     SELECT TIMESTAMPDIFF(minute,NEW.start_activity,NEW.end_activity) INTO minutes;


     IF (NEW.start_activity < start_date_activity OR NEW.end_activity >end_date_activity) THEN

         SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Your input date are invalids,check TABLE ACTIVITY ';

       end if ;


       IF (NEW.end_activity IS NOT NULL ) THEN
     IF (minutes < 0) then
       SIGNAL SQLSTATE '02000' SET MESSAGE_TEXT = 'Start activity must be lower than end_activity';

     end if ;

     IF (minutes>=thresold) THEN
     SET NEW.present=true;
       END IF ;

      END IF ;


   end;

